<h1>Odraude Lig</h1>
<br><br>
<hr>
<h1>Edardna</h1>

<br>
<ul>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li><?php echo e($item->nome); ?></li>
        <li><?php echo e($item->descricao); ?></li>
        <li><?php echo e($item->url); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH /home/aluno/Documentos/almi/31-07/WEBII-master/Docker/start-project/resources/views/eixo/pdf.blade.php ENDPATH**/ ?>