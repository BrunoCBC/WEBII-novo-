<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mais informações - Eixo</title>
</head>
<body>
    <h1>Mais informações - Eixo</h1>
    <hr>
    <a href="<?php echo e(route('eixo.index')); ?>" class="btn btn-success">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left" viewBox="0 0 16 16">
        <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8"/>
        </svg>
    </a>
    <hr>
    <ul>
        <li><b>ID:</b><?php echo e($eixo->id); ?></li>
        <li><b>NOME</b>:</b><?php echo e($eixo->nome); ?></li>
        <li><b>DESCRIÇÂO:</b><?php echo e($eixo->descricao); ?></li>
        <li><b>CRIADO:</b><?php echo e($eixo->created_at); ?></li>
        <li><b>ALTERADO:</b><?php echo e($eixo->updated_at); ?></li>
    </ul>
</body>
</html><?php /**PATH /home/aluno/Documentos/almi/31-07/WEBII-master/Docker/start-project/resources/views/eixo/show.blade.php ENDPATH**/ ?>